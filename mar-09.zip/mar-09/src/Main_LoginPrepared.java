import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main_LoginPrepared {

	public static void main(String[] args) throws SQLException
	{
		Scanner sc=new Scanner(System.in);
		String username=sc.nextLine();
		String password=sc.nextLine();
		Driver driver=new oracle.jdbc.driver.OracleDriver();
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:XE","sys as sysdba","password");
//		Statement st = con.createStatement();
		PreparedStatement st = con.prepareStatement("SELECT * FROM USER_MASTER WHERE USERID=? AND PASSWORD=?");
//		String sql=String.format("SELECT * FROM USER_MASTER WHERE USERID='%s' AND PASSWORD='%s'",username,password);
//		System.out.println(sql);
		//BEFORE EXECUTING QUERY, WE NEED TO SUPPLY VALUES FOR THOSE 2 QUESTION MARKS
		st.setString(1, username);
		st.setString(2, password);
		ResultSet rs = st.executeQuery();
		if(rs.next())
			System.out.println("Login is successful");
		else
			System.out.println("Failed to login");
		


	}

}
