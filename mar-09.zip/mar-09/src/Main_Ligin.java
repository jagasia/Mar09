import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main_Ligin {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		String username=sc.nextLine();
		String password=sc.nextLine();
		Driver driver=new oracle.jdbc.driver.OracleDriver();
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:XE","sys as sysdba","password");
		Statement st = con.createStatement();
		String sql=String.format("SELECT * FROM USER_MASTER WHERE USERID='%s' AND PASSWORD='%s'",username,password);
		System.out.println(sql);
		ResultSet rs = st.executeQuery(sql);
		if(rs.next())
			System.out.println("Login is successful");
		else
			System.out.println("Failed to login");
		
	}

}
