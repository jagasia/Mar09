package com.mphasis.hrms.view;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.mphasis.hrms.model.Associate;
import com.mphasis.hrms.model.AssociateDaoImpl;

public class Main_Associate {
	
	
	public static void main(String[] args) throws ParseException, IOException, ClassNotFoundException, SQLException {
		AssociateDaoImpl adao=new AssociateDaoImpl();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yy");
		Scanner sc=new Scanner(System.in);
		do
		{
			Long associateId;
			String firstName;
			String lastName;
			Date dateOfJoining;
			String gender;
			byte[] picture;
			Associate associate=null;
			System.out.println("	1) Add Associate\r\n" + 
					"	2) Update Associate\r\n" + 
					"	3) Remove Associate\r\n" + 
					"	4) Display All Associates\r\n" + 
					"	5) Find Associate by Id\r\n" + 
					"	6) Exit\r\n" + 
					"");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:			//add
				System.out.println("Please provide the values to add a new associate");
				System.out.println("Associate Id:");
				associateId=sc.nextLong();
				System.out.println("First Name:");
				firstName=sc.nextLine();
				if(firstName.equals(""))
					firstName=sc.nextLine();
				System.out.println("Last Name:");
				lastName=sc.nextLine();
				System.out.println("Date of Joining: (dd-MMM-yy)");
				dateOfJoining=sdf.parse(sc.nextLine());
				System.out.println("Gender:");
				gender=sc.nextLine();
				System.out.println("Picture: (pls enter the full path)");
				File f=new File(sc.nextLine());
				int len=(int)f.length();
				picture=new byte[len];
				FileInputStream fis=new FileInputStream(f);
				fis.read(picture);
				fis.close();
				associate=new Associate(associateId, firstName, lastName, dateOfJoining, gender, picture);
				adao.create(associate);
				System.out.println("Added...");
				
				break;
			case 2:			//update
				break;
			case 3:			//remove
				System.out.println("Please provide the associate ID to remove the associate");
				System.out.println("Associate Id:");
				associateId=sc.nextLong();
				adao.delete(associateId);
				System.out.println("Deleted...");
				break;
			case 4:			//display all
//				System.out.format("%-7s %-10s %-10s %-10s %-10s %10s\n", args)
				List<Associate> associates = adao.read();
				for(Associate a : associates)
					System.out.println(a);
				break;
			case 5:			//find by id
				System.out.println("Please provide the associate ID to find the associate");
				System.out.println("Associate Id:");
				associateId=sc.nextLong();
				associate=adao.read(associateId);
				System.out.println(associate);
				break;
			default:		//exit
					System.exit(0);
				break;
			}
		}while(true);
	}
}
